package com.example.chauffage_central

import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class ConfigActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_config)

        val buttonCancel = findViewById<Button>(R.id.cancel)

        val plage_horraire = findViewById<Button>(R.id.plage_horraire)
        val jour_ouvre = findViewById<Button>(R.id.jour_ouvre)
        val jour_repos = findViewById<Button>(R.id.jour_repos)

        buttonCancel.setOnClickListener {
            startActivity(Intent(this,MainActivity::class.java))
        }

        plage_horraire.setOnClickListener {
            plage_horraire.setBackgroundColor(Color.GREEN)
            jour_ouvre.setBackgroundColor(Color.GRAY)
            jour_repos.setBackgroundColor(Color.GRAY)
        }

        jour_ouvre.setOnClickListener {
            plage_horraire.setBackgroundColor(Color.GRAY)
            jour_ouvre.setBackgroundColor(Color.GREEN)
            jour_repos.setBackgroundColor(Color.GRAY)
        }

        jour_repos.setOnClickListener {
            plage_horraire.setBackgroundColor(Color.GRAY)
            jour_ouvre.setBackgroundColor(Color.GRAY)
            jour_repos.setBackgroundColor(Color.GREEN)
        }
    }
}