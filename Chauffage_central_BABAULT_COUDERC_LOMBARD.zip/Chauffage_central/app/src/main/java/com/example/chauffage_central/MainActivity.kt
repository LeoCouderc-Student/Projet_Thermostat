package com.example.chauffage_central

import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val buttonConfig = findViewById<Button>(R.id.Config)

        val manuel = findViewById<Button>(R.id.manuel)
        val mode1 = findViewById<Button>(R.id.mode1)
        val mode2 = findViewById<Button>(R.id.mode2)
        val mode3 = findViewById<Button>(R.id.mode3)
        val mode4 = findViewById<Button>(R.id.mode4)

        var deg = 20

        val moins = findViewById<Button>(R.id.moins)
        val plus = findViewById<Button>(R.id.plus)
        val degre = findViewById<TextView>(R.id.degre)

        moins.isClickable = true;
        moins?.setBackgroundColor(Color.BLACK)
        plus.isClickable = true;
        plus?.setBackgroundColor(Color.BLACK)

        buttonConfig.setOnClickListener {
            startActivity(Intent(this,ConfigActivity::class.java))
        }

        moins.setOnClickListener {
            deg = deg-1
            degre.setText(deg.toString() + "°")
        }

        plus.setOnClickListener {
            deg = deg+1
            degre.setText( deg.toString() + "°")
        }

        manuel.setOnClickListener {
            manuel.setBackgroundColor(Color.GREEN)
            mode1.setBackgroundColor(Color.GRAY)
            mode2.setBackgroundColor(Color.GRAY)
            mode3.setBackgroundColor(Color.GRAY)
            mode4.setBackgroundColor(Color.GRAY)

            moins.isClickable = true;
            moins?.setBackgroundColor(Color.BLACK)
            plus.isClickable = true;
            plus?.setBackgroundColor(Color.BLACK)
        }

        mode1.setOnClickListener {
            manuel.setBackgroundColor(Color.GRAY)
            mode1.setBackgroundColor(Color.GREEN)
            mode2.setBackgroundColor(Color.GRAY)
            mode3.setBackgroundColor(Color.GRAY)
            mode4.setBackgroundColor(Color.GRAY)

            moins.isClickable = false;
            moins?.setBackgroundColor(Color.WHITE)
            plus.isClickable = false;
            plus?.setBackgroundColor(Color.WHITE)
        }

        mode2.setOnClickListener {
            manuel.setBackgroundColor(Color.GRAY)
            mode1.setBackgroundColor(Color.GRAY)
            mode2.setBackgroundColor(Color.GREEN)
            mode3.setBackgroundColor(Color.GRAY)
            mode4.setBackgroundColor(Color.GRAY)

            moins.isClickable = false;
            moins?.setBackgroundColor(Color.WHITE)
            plus.isClickable = false;
            plus?.setBackgroundColor(Color.WHITE)
        }

        mode3.setOnClickListener {
            manuel.setBackgroundColor(Color.GRAY)
            mode1.setBackgroundColor(Color.GRAY)
            mode2.setBackgroundColor(Color.GRAY)
            mode3.setBackgroundColor(Color.GREEN)
            mode4.setBackgroundColor(Color.GRAY)

            moins.isClickable = false;
            moins?.setBackgroundColor(Color.WHITE)
            plus.isClickable = false;
            plus?.setBackgroundColor(Color.WHITE)
        }

        mode4.setOnClickListener {
            manuel.setBackgroundColor(Color.GRAY)
            mode1.setBackgroundColor(Color.GRAY)
            mode2.setBackgroundColor(Color.GRAY)
            mode3.setBackgroundColor(Color.GRAY)
            mode4.setBackgroundColor(Color.GREEN)

            moins.isClickable = false;
            moins?.setBackgroundColor(Color.WHITE)
            plus.isClickable = false;
            plus?.setBackgroundColor(Color.WHITE)
        }
    }
}